# Model: GPT4o

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Step 1: Load data
data = pd.read_excel('data.xlsx')

# Step 2: Split the data into features (temperature, pressure) and target (catalytic recombination coefficient)
X = data.iloc[:, 0:2].values  # temperature and pressure
y = data.iloc[:, 2].values    # catalytic recombination coefficient

# Step 3: Split the data into training and testing sets (80% training, 20% testing)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 4: Train the surrogate model using Random Forest Regressor
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Step 5: Make predictions on the test set
y_pred = model.predict(X_test)

# Step 6: Calculate the regression coefficient (R² score)
r2 = r2_score(y_test, y_pred)
print(f'R² Regression Coefficient on the Test Set: {r2:.4f}')

# Step 7: Visualize the predictions on the test set
plt.figure(figsize=(8, 6))
plt.scatter(y_pred, y_test, color='blue', label='Predicted vs True')
plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], color='red', label='Ideal Line')
plt.xlabel('Predicted Value')
plt.ylabel('True Value')
plt.title('Predicted vs True Catalytic Recombination Coefficient on Test Set')
plt.legend()
plt.grid(True)

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('3.png', dpi=1200)

plt.show()
