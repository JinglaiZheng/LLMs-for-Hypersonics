# Model: DeepSeek-V3

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt

# Load the data from the Excel file
data = pd.read_excel('data.xlsx')

# Assuming the first column is temperature, the second is pressure, and the third is the catalytic recombination coefficient
X = data.iloc[:, :2]  # Input features: temperature and pressure
y = data.iloc[:, 2]   # Output: catalytic recombination coefficient

# Split the data into training and test sets (80% training, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize the Random Forest Regressor
model = RandomForestRegressor(n_estimators=100, random_state=42)

# Train the model
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)

# Calculate the regression coefficient (R^2 score)
r2 = r2_score(y_test, y_pred)
print(f'Regression Coefficient (R^2) on the test set: {r2:.4f}')

# Visualize the predictions
plt.figure(figsize=(8, 6))
plt.scatter(y_pred, y_test, alpha=0.5)
plt.plot([min(y_pred), max(y_pred)], [min(y_pred), max(y_pred)], color='red', linestyle='--')
plt.xlabel('Predicted Catalytic Recombination Coefficient')
plt.ylabel('True Catalytic Recombination Coefficient')
plt.title('Predicted vs True Catalytic Recombination Coefficient')
plt.grid(True)

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('2.png', dpi=1200)

plt.show()