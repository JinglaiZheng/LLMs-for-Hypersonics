# Model: Qwen2.5

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt

# Load data from Excel file
data = pd.read_excel('data.xlsx')

# Split features (temperature, pressure) and target (catalytic recombination coefficient)
X = data.iloc[:, :2]  # Temperature and Pressure
y = data.iloc[:, 2]   # Catalytic Recombination Coefficient

# Split dataset into training (80%) and test set (20%)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize the model
model = RandomForestRegressor(n_estimators=100, random_state=42)

# Train the model
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)

# Calculate R^2 score on the test set
r2 = r2_score(y_test, y_pred)
print(f"R^2 Score on Test Set: {r2}")

# Visualization
plt.figure(figsize=(10, 6))
plt.scatter(y_test, y_pred, color='blue', label=f'R^2={r2:.2f}')
plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], '--k', label='Perfect Prediction')
plt.xlabel('True Values')
plt.ylabel('Predicted Values')
plt.title('True vs Predicted Values on Test Set')
plt.legend()

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('4.png', dpi=1200)

plt.show()

# Print feature importance (regression coefficients equivalent in tree-based models)
importances = model.feature_importances_
print(f"Feature Importances: Temperature={importances[0]:.2f}, Pressure={importances[1]:.2f}")