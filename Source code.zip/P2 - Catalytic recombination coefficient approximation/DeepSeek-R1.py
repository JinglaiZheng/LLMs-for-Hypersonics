# Model: DeepSeek-R1

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import r2_score

# Load the data
df = pd.read_excel('data.xlsx')
X = df.iloc[:, [0, 1]].values  # Temperature and Pressure
y = df.iloc[:, 2].values        # Catalytic recombination coefficient

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Hyperparameter tuning setup
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [3, 5, 7],
    'learning_rate': [0.1, 0.05, 0.01]
}

# Initialize and train the model with grid search
gb_model = GradientBoostingRegressor(random_state=42)
grid_search = GridSearchCV(estimator=gb_model, param_grid=param_grid,
                           cv=5, scoring='r2', n_jobs=-1)
grid_search.fit(X_train, y_train)

# Get the best model
best_model = grid_search.best_estimator_
print(f"Optimal Parameters: {grid_search.best_params_}")

# Make predictions and evaluate
y_pred = best_model.predict(X_test)
test_r2 = r2_score(y_test, y_pred)
print(f"Test Set R² Score: {test_r2:.4f}")

# Visualization
plt.figure(figsize=(8, 6))
plt.scatter(y_pred, y_test, alpha=0.6, edgecolors='w', color='blue')
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'k--', lw=2)
plt.xlabel('Predicted Catalytic Recombination Coefficient', fontsize=12)
plt.ylabel('Actual Catalytic Recombination Coefficient', fontsize=12)
plt.title(f'Predicted vs Actual Values (Test Set R² = {test_r2:.4f})', fontsize=14)
plt.grid(True, linestyle='--', alpha=0.7)
plt.tight_layout()

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('1.png', dpi=1200)

plt.show()