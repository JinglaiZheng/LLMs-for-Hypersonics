# Model: Qwen2.5

import numpy as np
import matplotlib.pyplot as plt

# Constants
gamma = 1.4  # Ratio of specific heats for an ideal gas


def initial_conditions(x):
    """Set up the initial conditions for the Sod shock tube problem."""
    rho = np.where(x < 0.5, 1.0, 0.125)  # Density
    u = np.zeros_like(x)  # Velocity
    p = np.where(x < 0.5, 1.0, 0.1)  # Pressure

    return rho, u, p


def euler_flux(rho, u, p):
    """Compute the Euler fluxes."""
    e = p / (gamma - 1.0) + 0.5 * rho * u ** 2  # Total energy
    f_mass = rho * u
    f_momentum = rho * u ** 2 + p
    f_energy = (e + p) * u

    return np.stack((f_mass, f_momentum, f_energy))


def main():
    nx = 1000  # Number of grid points
    nt = 1000  # Number of time steps
    dx = 1.0 / (nx - 1)  # Grid spacing
    dt = 0.001  # Time step size

    x = np.linspace(0, 1, nx)
    rho, u, p = initial_conditions(x)

    for t in range(nt):
        f = euler_flux(rho, u, p)
        rho_new = rho - dt / dx * (f[0, 1:] - f[0, :-1])
        u_new = u - dt / dx * (f[1, 1:] / rho[1:] - f[1, :-1] / rho[:-1])
        p_new = p - dt / dx * ((f[2, 1:] - f[2, :-1]) - u[1:] * (f[0, 1:] - f[0, :-1]))

        rho, u, p = rho_new, u_new, p_new

    plt.plot(x, rho, label="Density")
    plt.plot(x, u, label="Velocity")
    plt.plot(x, p, label="Pressure")
    plt.legend()
    plt.show()


if __name__ == "__main__":
    main()