# Model: GPT4o

import numpy as np
import matplotlib.pyplot as plt

# Define constants
gamma = 1.4  # Adiabatic index


# Define initial conditions for the left and right states
def initial_conditions(x, x0, left_state, right_state):
    """Piecewise constant initial condition."""
    if x < x0:
        return left_state  # Left state
    else:
        return right_state  # Right state


# Define a function to calculate pressure from the state
def pressure(state):
    rho, u, E = state
    return (gamma - 1) * (E - 0.5 * rho * u ** 2)


# Define a function to calculate the flux vector
def flux(state):
    rho, u, E = state
    p = pressure(state)
    flux_vec = np.zeros_like(state)
    flux_vec[0] = rho * u  # mass flux
    flux_vec[1] = rho * u ** 2 + p  # momentum flux
    flux_vec[2] = u * (E + p)  # energy flux
    return flux_vec


# Lax-Friedrichs method for solving the Riemann problem
def lax_friedrichs(u_left, u_right, nx, x_min, x_max, t_max, dt):
    dx = (x_max - x_min) / nx
    x = np.linspace(x_min, x_max, nx)
    t = 0

    # Initial condition
    U = np.zeros((nx, 3))  # Array to store conservative variables [rho, rho*u, E]

    # Set initial conditions
    for i in range(nx):
        U[i, :] = initial_conditions(x[i], 0.5 * (x_min + x_max), u_left, u_right)

    # Time-stepping loop
    while t < t_max:
        U_new = np.copy(U)

        # Update U using Lax-Friedrichs scheme
        for i in range(1, nx - 1):
            flux_left = flux(U[i - 1, :])
            flux_right = flux(U[i, :])

            # Lax-Friedrichs update
            U_new[i, :] = 0.5 * (U[i - 1, :] + U[i, :]) - 0.5 * (dt / dx) * (flux_right - flux_left)

        U = np.copy(U_new)
        t += dt

    return x, U


# Set up parameters for the simulation
nx = 200  # Number of grid points
x_min = 0.0  # Minimum x position
x_max = 1.0  # Maximum x position
t_max = 0.2  # Total simulation time
dt = 0.001  # Time step

# Left state [rho, u, E] and right state [rho, u, E]
left_state = [1.0, 0.0, 2.5]  # Density=1.0, Velocity=0.0, Energy=2.5
right_state = [0.125, 0.0, 0.25]  # Density=0.125, Velocity=0.0, Energy=0.25

# Solve the Riemann problem
x, U = lax_friedrichs(left_state, right_state, nx, x_min, x_max, t_max, dt)

# Extract density, velocity, and pressure from U
rho = U[:, 0]
u = U[:, 1] / rho  # Velocity = momentum / density
E = U[:, 2]
p = pressure(U.T)

# Plot results
fig, axs = plt.subplots(3, 1, figsize=(12, 8))

# Plot density
axs[0].plot(x, rho, label='Density (rho)')
axs[0].set_title("Density Profile")
axs[0].set_xlabel("x")
axs[0].set_ylabel("Density")
axs[0].grid(True)

# Plot velocity
axs[1].plot(x, u, label='Velocity (u)', color='r')
axs[1].set_title("Velocity Profile")
axs[1].set_xlabel("x")
axs[1].set_ylabel("Velocity (u)")
axs[1].grid(True)

# Plot pressure
axs[2].plot(x, p, label='Pressure (p)', color='g')
axs[2].set_title("Pressure Profile")
axs[2].set_xlabel("x")
axs[2].set_ylabel("Pressure (p)")
axs[2].grid(True)

plt.tight_layout()

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('3.png', dpi=1200)

plt.show()
