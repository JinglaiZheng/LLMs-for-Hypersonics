# Model: Deepseek-R1

import numpy as np
import matplotlib.pyplot as plt

# Parameters
gamma = 1.4
x_left = -0.5
x_right = 0.5
N = 1000  # Number of cells
dx = (x_right - x_left) / N
CFL = 0.5
t_final = 0.2

# Initial conditions (Sod problem)
# Left state
rho_L = 1.0
u_L = 0.0
p_L = 1.0
# Right state
rho_R = 0.125
u_R = 0.0
p_R = 0.1

# Initialize conserved variables Q = [rho, rho*u, E]
Q = np.zeros((N, 3))
x_centers = np.linspace(x_left + 0.5 * dx, x_right - 0.5 * dx, N)

for i in range(N):
    if x_centers[i] < 0.0:
        rho, u, p = rho_L, u_L, p_L
    else:
        rho, u, p = rho_R, u_R, p_R
    Q[i, 0] = rho
    Q[i, 1] = rho * u
    Q[i, 2] = p / (gamma - 1) + 0.5 * rho * u ** 2

# Time stepping
t = 0.0
while t < t_final:
    # Compute maximum wave speed to determine time step
    max_speed = 0.0
    for i in range(N):
        rho = Q[i, 0]
        rhou = Q[i, 1]
        E = Q[i, 2]
        if rho < 1e-10:
            u = 0.0
        else:
            u = rhou / rho
        p = (gamma - 1) * (E - 0.5 * rhou ** 2 / rho)
        p = max(p, 1e-10)  # Ensure non-negative pressure
        c = np.sqrt(gamma * p / rho)
        wave_speed = max(abs(u - c), abs(u + c))
        max_speed = max(max_speed, wave_speed)

    dt = CFL * dx / max_speed
    if t + dt > t_final:
        dt = t_final - t

    # Compute fluxes at each interface using Rusanov scheme
    flux = np.zeros((N + 1, 3))
    for i in range(N + 1):
        if i == 0:
            Q_L, Q_R = Q[0], Q[0]
        elif i == N:
            Q_L, Q_R = Q[-1], Q[-1]
        else:
            Q_L, Q_R = Q[i - 1], Q[i]

        # Compute left flux
        rho_L, rhou_L, E_L = Q_L
        u_L = rhou_L / rho_L if rho_L > 1e-10 else 0.0
        p_L = (gamma - 1) * (E_L - 0.5 * rhou_L ** 2 / rho_L)
        p_L = max(p_L, 1e-10)
        F_L = np.array([rhou_L, rhou_L * u_L + p_L, u_L * (E_L + p_L)])

        # Compute right flux
        rho_R, rhou_R, E_R = Q_R
        u_R = rhou_R / rho_R if rho_R > 1e-10 else 0.0
        p_R = (gamma - 1) * (E_R - 0.5 * rhou_R ** 2 / rho_R)
        p_R = max(p_R, 1e-10)
        F_R = np.array([rhou_R, rhou_R * u_R + p_R, u_R * (E_R + p_R)])

        # Compute wave speeds
        c_L = np.sqrt(gamma * p_L / rho_L)
        c_R = np.sqrt(gamma * p_R / rho_R)
        S_max = max(max(abs(u_L - c_L), abs(u_L + c_L)),
                    max(abs(u_R - c_R), abs(u_R + c_R)))

        # Rusanov flux
        flux[i] = 0.5 * (F_L + F_R) - 0.5 * S_max * (Q_R - Q_L)

    # Update conserved variables
    Q_new = np.zeros_like(Q)
    for i in range(N):
        Q_new[i] = Q[i] - (dt / dx) * (flux[i + 1] - flux[i])
    Q = Q_new.copy()
    t += dt
    print(f"Time: {t:.3f}")

# Plot results
x_plot = x_centers
rho = Q[:, 0]
u = Q[:, 1] / np.where(Q[:, 0] > 1e-10, Q[:, 0], 1e-10)
p = (gamma - 1) * (Q[:, 2] - 0.5 * rho * u ** 2)

plt.figure(figsize=(12, 8))
plt.subplot(3, 1, 1)
plt.plot(x_plot, rho)
plt.ylabel('Density')
plt.subplot(3, 1, 2)
plt.plot(x_plot, u)
plt.ylabel('Velocity')
plt.subplot(3, 1, 3)
plt.plot(x_plot, p)
plt.ylabel('Pressure')
plt.xlabel('x')
plt.tight_layout()

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('1.png', dpi=1200)

plt.show()