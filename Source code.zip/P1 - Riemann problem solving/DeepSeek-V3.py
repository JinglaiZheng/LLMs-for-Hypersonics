# Model: Deepseek-V3

import numpy as np
import matplotlib.pyplot as plt

# Constants
gamma = 1.4  # Adiabatic index for air

# Initial conditions
rho_L, u_L, p_L = 1.0, 0.0, 1.0  # Left state
rho_R, u_R, p_R = 0.125, 0.0, 0.1  # Right state

# Domain
x_min, x_max = -1.0, 1.0
x0 = 0.0  # Initial discontinuity position
nx = 1000  # Number of grid points
dx = (x_max - x_min) / nx
x = np.linspace(x_min, x_max, nx)

# Time parameters
t_end = 0.25
cfl = 0.5  # CFL condition

# Initialize arrays
rho = np.where(x < x0, rho_L, rho_R)
u = np.where(x < x0, u_L, u_R)
p = np.where(x < x0, p_L, p_R)

# Compute conserved variables
U = np.zeros((3, nx))
U[0, :] = rho
U[1, :] = rho * u
U[2, :] = p / (gamma - 1) + 0.5 * rho * u ** 2


# Exact Riemann solver (simplified for this example)
def exact_riemann_solver(rho_L, u_L, p_L, rho_R, u_R, p_R, gamma):
    # Placeholder for exact Riemann solver
    # This is a simplified version; a full implementation is complex
    # and involves solving the nonlinear Riemann problem exactly.
    # For simplicity, we assume a shock tube solution.
    rho_star = 0.5 * (rho_L + rho_R)
    u_star = 0.5 * (u_L + u_R)
    p_star = 0.5 * (p_L + p_R)
    return rho_star, u_star, p_star


# Time integration
t = 0.0
while t < t_end:
    # Compute time step
    a = np.sqrt(gamma * p / rho)  # Speed of sound
    dt = cfl * dx / np.max(np.abs(u) + a)

    # Update solution using Godunov's method
    for i in range(1, nx - 1):
        # Solve Riemann problem at the interface
        rho_star, u_star, p_star = exact_riemann_solver(rho[i - 1], u[i - 1], p[i - 1], rho[i], u[i], p[i], gamma)

        # Compute fluxes
        F_L = np.array([rho[i - 1] * u[i - 1],
                        rho[i - 1] * u[i - 1] ** 2 + p[i - 1],
                        u[i - 1] * (U[2, i - 1] + p[i - 1])])

        F_R = np.array([rho[i] * u[i],
                        rho[i] * u[i] ** 2 + p[i],
                        u[i] * (U[2, i] + p[i])])

        F_star = np.array([rho_star * u_star,
                           rho_star * u_star ** 2 + p_star,
                           u_star * (0.5 * rho_star * u_star ** 2 + p_star / (gamma - 1) + p_star)])

        # Update conserved variables
        U[:, i] = U[:, i] - dt / dx * (F_star - F_L)

    # Update primitive variables
    rho = U[0, :]
    u = U[1, :] / rho
    p = (gamma - 1) * (U[2, :] - 0.5 * rho * u ** 2)

    # Update time
    t += dt

# Plot results
plt.figure(figsize=(12, 8))

plt.subplot(3, 1, 1)
plt.plot(x, rho, label='Density')
plt.ylabel('Density')
plt.legend()

plt.subplot(3, 1, 2)
plt.plot(x, u, label='Velocity')
plt.ylabel('Velocity')
plt.legend()

plt.subplot(3, 1, 3)
plt.plot(x, p, label='Pressure')
plt.ylabel('Pressure')
plt.legend()

plt.xlabel('x')

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('2.png', dpi=1200)

plt.show()