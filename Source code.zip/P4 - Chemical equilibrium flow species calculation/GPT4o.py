# Model: GPT4o

import numpy as np
import scipy.constants as const
from scipy.optimize import fsolve
import matplotlib.pyplot as plt

# Constants for the equilibrium reactions (coefficients for lnK = ΣAi * (10000/T)^i)
A_O2 = [1.335, -4.127, -0.616, 0.093, -0.005]
A_N2 = [3.898, -12.611, 0.683, -0.118, 0.006]
A_NO = [1.549, -7.784, 0.228, -0.043, 0.002]

# Molecular weights for the components
M_O2 = 32.00  # g/mol
M_N2 = 28.0134  # g/mol
M_NO = 30.01  # g/mol
M_O = 16.00  # g/mol
M_N = 14.007  # g/mol

# Calculate equilibrium constant for a given temperature (K)
def equilibrium_constant(A, T):
    T_inv = 10000 / T
    lnK = sum(a * (T_inv**i) for i, a in enumerate(A))
    return np.exp(lnK)

# Define the system of equations to solve (conservation of mass and atomic ratios)
def system_of_equations(x, T, P_total):
    O2, N2, NO, O, N = x
    # Equilibrium constants for each reaction
    K_O2 = equilibrium_constant(A_O2, T)
    K_N2 = equilibrium_constant(A_N2, T)
    K_NO = equilibrium_constant(A_NO, T)

    # Reaction equilibrium equations
    eq1 = (O2 * N) - (2 * O * N2 / P_total) * K_O2  # O2 ↔ 2O
    eq2 = (N2 * O) - (2 * N * O2 / P_total) * K_N2  # N2 ↔ 2N
    eq3 = (NO * O) - (N * O2 / P_total) * K_NO  # NO ↔ N + O

    # Conservation equations
    # 1. Conservation of oxygen-to-nitrogen atomic ratio
    eq4 = (O2 + 2 * O + NO) / P_total - 0.21  # Initial ratio of O2 to N2 in air = 21% O2
    eq5 = O2 + N2 + NO + O + N - P_total  # Total pressure conservation

    return [eq1, eq2, eq3, eq4, eq5]

# Temperature range (4000K - 10000K)
temperatures = np.linspace(4000, 10000, 100)

# Initial guesses for partial pressures (scaled by P_total)
initial_guess = [0.050, 0.675, 0.056, 0.218, 0.001]

# Store the results for mass fractions
mass_fractions = {"O2": [], "N2": [], "NO": [], "O": [], "N": []}

# Loop over each temperature to solve the system
for T in temperatures:
    # Solve the system of equations using fsolve
    result = fsolve(system_of_equations, initial_guess, args=(T, 1))  # P_total = 1 atm for simplicity
    O2, N2, NO, O, N = result

    # Mass fractions
    mass_fractions["O2"].append(O2 * M_O2 / (O2 * M_O2 + N2 * M_N2 + NO * M_NO + O * M_O + N * M_N))
    mass_fractions["N2"].append(N2 * M_N2 / (O2 * M_O2 + N2 * M_N2 + NO * M_NO + O * M_O + N * M_N))
    mass_fractions["NO"].append(NO * M_NO / (O2 * M_O2 + N2 * M_N2 + NO * M_NO + O * M_O + N * M_N))
    mass_fractions["O"].append(O * M_O / (O2 * M_O2 + N2 * M_N2 + NO * M_NO + O * M_O + N * M_N))
    mass_fractions["N"].append(N * M_N / (O2 * M_O2 + N2 * M_N2 + NO * M_NO + O * M_O + N * M_N))

    # Use the result as the initial guess for the next temperature
    initial_guess = result

# Plot the results
plt.figure(figsize=(10, 6))
plt.plot(temperatures, mass_fractions["O2"], label="O2", color="blue")
plt.plot(temperatures, mass_fractions["N2"], label="N2", color="green")
plt.plot(temperatures, mass_fractions["NO"], label="NO", color="red")
plt.plot(temperatures, mass_fractions["O"], label="O", color="orange")
plt.plot(temperatures, mass_fractions["N"], label="N", color="purple")

plt.xlabel('Temperature (K)')
plt.ylabel('Mass Fraction')
plt.title('Mass Fractions of Air Components as a Function of Temperature')
plt.legend()
plt.grid(True)

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('3.png', dpi=1200)

plt.show()
