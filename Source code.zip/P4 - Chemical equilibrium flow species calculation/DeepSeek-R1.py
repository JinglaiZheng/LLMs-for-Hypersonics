# Model: Deepseek-R1

import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt

# Constants
R = 8.314  # J/(mol·K)
P_total = 1/101325 # Total pressure
molar_mass = {'O2': 32e-3, 'N2': 28e-3, 'NO': 30e-3, 'O': 16e-3, 'N': 14e-3}  # kg/mol

# Park's coefficients for equilibrium constants
A_coeff = {
    'O2': [1.335, -4.127, -0.616, 0.093, -0.005],
    'N2': [3.898, -12.611, 0.683, -0.118, 0.006],
    'NO': [1.549, -7.784, 0.228, -0.043, 0.002]
}


def calc_equilibrium_constants(T):
    """Calculate equilibrium constants for all reactions"""
    K = {}
    theta = 10000 / T

    # O2 ↔ 2O
    lnK = sum(a * theta ** i for i, a in enumerate(A_coeff['O2']))
    K['O2'] = np.exp(lnK)

    # N2 ↔ 2N
    lnK = sum(a * theta ** i for i, a in enumerate(A_coeff['N2']))
    K['N2'] = np.exp(lnK)

    # NO ↔ N + O
    lnK = sum(a * theta ** i for i, a in enumerate(A_coeff['NO']))
    K['NO'] = np.exp(lnK)

    return K


def equations(vars, T, P_total):
    p_O2, p_N2, p_NO, p_O, p_N = vars
    K = calc_equilibrium_constants(T)

    # Equilibrium equations
    eq1 = p_O ** 2 / p_O2 - K['O2']
    eq2 = p_N ** 2 / p_N2 - K['N2']
    eq3 = (p_N * p_O) / p_NO - K['NO']

    # Conservation equations
    total_pressure = p_O2 + p_N2 + p_NO + p_O + p_N - P_total

    # Atomic ratio conservation (O:N = 21:79 from initial air composition)
    O_atoms = 2 * p_O2 + p_NO + p_O
    N_atoms = 2 * p_N2 + p_NO + p_N
    atomic_ratio = (O_atoms / N_atoms) - (21 / 79)

    return [eq1, eq2, eq3, total_pressure, atomic_ratio]


# Temperature range
T_range = np.linspace(4000, 10000, 100)
results = []

# Initial guess
initial_guess = np.array([0.050, 0.675, 0.056, 0.218, 0.001]) * P_total

# Solve for each temperature
for T in T_range:
    sol = fsolve(equations, initial_guess, args=(T, P_total))
    results.append(sol)
    initial_guess = sol  # Use previous solution as new guess

# Convert to numpy array
results = np.array(results)

# Calculate mole fractions
mole_fractions = results / P_total

# Calculate mass fractions
molar_masses = np.array([molar_mass['O2'], molar_mass['N2'],
                         molar_mass['NO'], molar_mass['O'], molar_mass['N']])
mass_fractions = mole_fractions * molar_masses
mass_fractions /= mass_fractions.sum(axis=1)[:, np.newaxis]

# Plot results
plt.figure(figsize=(10, 6))
components = ['O2', 'N2', 'NO', 'O', 'N']
for i, comp in enumerate(components):
    plt.plot(T_range, mass_fractions[:, i], label=comp)

plt.title('Mass Fractions of Air Components vs Temperature')
plt.xlabel('Temperature (K)')
plt.ylabel('Mass Fraction')
plt.legend()
plt.grid(True)

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('1.png', dpi=1200)

plt.show()