# Model: Qwen2.5

import numpy as np
from scipy.optimize import fsolve
import matplotlib.pyplot as plt


# Equilibrium constants calculation
def lnK(T, coeffs):
    return sum([coeffs[i] * (10000 / T) ** i for i in range(len(coeffs))])


# System of equations
def equations(vars, T, P_total, prev_solution):
    O2, N2, NO, O, N = vars
    # Equilibrium constants at given temperature
    K_O2 = np.exp(lnK(T, [1.335, -4.127, -0.616, 0.093, -0.005]))
    K_N2 = np.exp(lnK(T, [3.898, -12.611, 0.683, -0.118, 0.006]))
    K_NO = np.exp(lnK(T, [1.549, -7.784, 0.228, -0.043, 0.002]))

    # Partial pressures
    p_O2 = O2 * P_total
    p_N2 = N2 * P_total
    p_NO = NO * P_total
    p_O = O * P_total
    p_N = N * P_total

    # Equilibrium equations
    eq1 = K_O2 - (p_O ** 2) / p_O2 if p_O2 != 0 else 0
    eq2 = K_N2 - (p_N ** 2) / p_N2 if p_N2 != 0 else 0
    eq3 = K_NO - (p_N * p_O) / p_NO if p_NO != 0 else 0

    # Conservation of atoms
    eq4 = (2 * O2 + NO + O) - 0.21  # Oxygen conservation
    eq5 = (2 * N2 + NO + N) - 0.79  # Nitrogen conservation

    return [eq1, eq2, eq3, eq4, eq5]


# Initial conditions
P_total = 1  # Assume total pressure is 1 atm for simplicity
T_range = np.linspace(4000, 10000, 100)
initial_guess = [0.050, 0.675, 0.056, 0.218, 0.001]

mass_fractions = []
for T in T_range:
    solution = fsolve(equations, initial_guess, args=(T, P_total, initial_guess))
    initial_guess = solution  # Use the previous solution as the next guess
    mass_fractions.append(solution)

mass_fractions = np.array(mass_fractions)

# Plotting
plt.figure(figsize=(10, 6))
components = ['O2', 'N2', 'NO', 'O', 'N']
for idx, comp in enumerate(components):
    plt.plot(T_range, mass_fractions[:, idx], label=comp)

plt.xlabel('Temperature (K)')
plt.ylabel('Mass Fraction')
plt.title('Mass Fractions of Air Components vs Temperature')
plt.legend()
plt.grid(True)

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('4.png', dpi=1200)

plt.show()