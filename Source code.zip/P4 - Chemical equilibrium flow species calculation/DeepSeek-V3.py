# Model: DeepSeek-V3

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve

# Constants
R = 8.314  # Universal gas constant (J/mol·K)
P_total = 1/101325  # Total pressure
T_range = np.linspace(4000, 10000, 100)  # Temperature range (4000K-10000K)

# Equilibrium constant coefficients (Park)
A_O2 = [1.335, -4.127, -0.616, 0.093, -0.005]
A_N2 = [3.898, -12.611, 0.683, -0.118, 0.006]
A_NO = [1.549, -7.784, 0.228, -0.043, 0.002]

# Initial partial pressures (guess)
initial_pressures = [0.050 * P_total, 0.675 * P_total, 0.056 * P_total, 0.218 * P_total, 0.001 * P_total]

# Atomic mass (g/mol)
M_O2 = 32.0
M_N2 = 28.0
M_NO = 30.0
M_O = 16.0
M_N = 14.0

# Function to calculate equilibrium constant (lnK)
def calc_lnK(A, T):
    return sum(A[i] * (10000 / T) ** i for i in range(5))

# System of equations to solve
def equations(p, T):
    P_O2, P_N2, P_NO, P_O, P_N = p

    # Equilibrium constants
    lnK_O2 = calc_lnK(A_O2, T)
    lnK_N2 = calc_lnK(A_N2, T)
    lnK_NO = calc_lnK(A_NO, T)

    K_O2 = np.exp(lnK_O2)
    K_N2 = np.exp(lnK_N2)
    K_NO = np.exp(lnK_NO)

    # Equilibrium equations
    eq1 = P_O ** 2 / P_O2 - K_O2
    eq2 = P_N ** 2 / P_N2 - K_N2
    eq3 = (P_N * P_O) / P_NO - K_NO

    # Conservation equations
    # 1. Conservation of oxygen-to-nitrogen atomic ratio (initial air ratio 21% O2 : 79% N2)
    eq4 = (2 * P_O2 + P_NO + P_O) / (2 * P_N2 + P_NO + P_N) - 0.21 / 0.79

    # 2. Sum of partial pressures equals total pressure
    eq5 = P_O2 + P_N2 + P_NO + P_O + P_N - P_total

    return [eq1, eq2, eq3, eq4, eq5]

# Solve the system for each temperature
pressures = []
for T in T_range:
    if not pressures:
        # Use initial guess for the first temperature
        sol = fsolve(equations, initial_pressures, args=(T))
    else:
        # Use previous solution as initial guess
        sol = fsolve(equations, pressures[-1], args=(T))
    pressures.append(sol)

# Convert pressures to mass fractions
mass_fractions = []
for p in pressures:
    P_O2, P_N2, P_NO, P_O, P_N = p

    # Calculate mole fractions
    total_moles = P_O2 + P_N2 + P_NO + P_O + P_N
    y_O2 = P_O2 / total_moles
    y_N2 = P_N2 / total_moles
    y_NO = P_NO / total_moles
    y_O = P_O / total_moles
    y_N = P_N / total_moles

    # Calculate mass fractions
    mass_O2 = y_O2 * M_O2
    mass_N2 = y_N2 * M_N2
    mass_NO = y_NO * M_NO
    mass_O = y_O * M_O
    mass_N = y_N * M_N

    total_mass = mass_O2 + mass_N2 + mass_NO + mass_O + mass_N
    w_O2 = mass_O2 / total_mass
    w_N2 = mass_N2 / total_mass
    w_NO = mass_NO / total_mass
    w_O = mass_O / total_mass
    w_N = mass_N / total_mass

    mass_fractions.append([w_O2, w_N2, w_NO, w_O, w_N])

# Plot the results
mass_fractions = np.array(mass_fractions)
plt.figure(figsize=(10, 6))
plt.plot(T_range, mass_fractions[:, 0], label="O₂")
plt.plot(T_range, mass_fractions[:, 1], label="N₂")
plt.plot(T_range, mass_fractions[:, 2], label="NO")
plt.plot(T_range, mass_fractions[:, 3], label="O")
plt.plot(T_range, mass_fractions[:, 4], label="N")
plt.xlabel("Temperature (K)")
plt.ylabel("Mass Fraction")
plt.title("Mass Fractions of Air Components at High Temperature")
plt.legend()
plt.grid()

# Add by user to save Fig.
plt.tight_layout()
plt.savefig('2.png', dpi=1200)

plt.show()